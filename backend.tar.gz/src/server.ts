import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import db from './db';
import { login, verifyToken } from './auth';

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes de test
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'KTM CRM API is running' });
});

// Authentification
app.post('/api/login', login);

// Récupérer les produits (Exemple sécurisé)
app.get('/api/products', verifyToken, async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM products ORDER BY name ASC');
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
